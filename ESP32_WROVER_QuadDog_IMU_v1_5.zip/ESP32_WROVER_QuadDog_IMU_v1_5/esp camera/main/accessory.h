#pragma once

#include <sys/types.h>
#include <sys/socket.h>

void camera_accessory_init();
void camera_accessory_set_ip_address(ip4_addr_t ip);
