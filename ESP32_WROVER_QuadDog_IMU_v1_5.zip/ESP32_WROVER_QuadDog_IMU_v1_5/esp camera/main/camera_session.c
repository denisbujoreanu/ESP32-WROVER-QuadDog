#include <stdlib.h>
#include <sys/socket.h>

#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

#include "camera_session.h"


camera_session_t *camera_session_new() {
    camera_session_t *session = calloc(1, sizeof(camera_session_t));
    session->video_ssrc = 1;
    session->audio_ssrc = 1;

    return session;
}


void camera_session_free(camera_session_t *session) {
    if (!session)
        return;

    if (session->controller_ip_address)
        free(session->controller_ip_address);

    free(session);
}
