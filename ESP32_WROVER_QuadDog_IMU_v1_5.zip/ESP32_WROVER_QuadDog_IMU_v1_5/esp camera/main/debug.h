#ifndef __DEBUG_H__
#define __DEBUG_H__

#include <stdint.h>

void dump_binary(const char *prompt, const uint8_t *data, size_t size);

#endif // __DEBUG_H__
