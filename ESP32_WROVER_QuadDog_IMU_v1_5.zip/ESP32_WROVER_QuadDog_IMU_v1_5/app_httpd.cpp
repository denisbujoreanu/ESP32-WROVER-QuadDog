#include "esp_http_server.h"
#include "esp_timer.h"
#include "esp_camera.h"
#include "img_converters.h"
#include "camera_index.h"
#include "Arduino.h"
#include <Adafruit_PWMServoDriver.h>


extern int gpLed;
extern String WiFiAddr;
byte txdata[3] = { 0xA5, 0, 0x5A };
const int Forward = 2;
const int Backward = 3;
const int Turn_Left = 4;
const int Turn_Right = 5;
const int Start = 1;
const int Stop = 0;
const int SpeedLow = 6;   // motor speed low
const int SpeedHigh = 7;  // motor speed high
const int SonarOn = 8;
const int SonarOff = 11;
const int StepLeft = 9;
const int Crouch = 12;
const int StepRight = 10;
const int Stand = 13;
const int Ping = 14;
const int Center = 15;
const int Legpos = 16;

const int Look_Left = 17;
const int Look_Right = 18;
const int Look_Up = 19;
const int Look_Down = 20;

const int Shift_Left = 21;
const int Shift_Right = 22;
const int Shift_Up = 23;
const int Shift_Down = 24;
const int Shift_Fwd = 25;
const int Shift_Back = 26;

const int Roll_Left = 27;
const int Roll_Right = 28;

const int Calibrate = 29;
const int Sit = 30;
const int RotateCamera = 31;
const int TrotStep = 32;
const int Ticks = 33;
const int ResetIMU = 34;


String pageTitle = "ESP32-WROVER QuadDog IMU v1.4";
int range;
char distBuf[16];
char rangeBfr[3];
bool sonar_flag = false;
bool hasIMUSensor = false;

int legNr_int;
int legX_int;
int legY_int;
int legZ_int;

String newCmd = "";

char stepLeftSwitch[32] = {
  0,
};

char stepRightSwitch[32] = {
  0,
};

char legMvSwitch[32] = {
  0,
};

char useIMUSwitch[32] = {
  0,
};

char gaitModeSwitch[32] = {
  0,
};

char turnModeSwitch[32] = {
  0,
};

char legMoveStep[32] = {
  0,
};

char ticksPerStepStr[32] = {
  0,
};


char legMvSpd[32] = {
  0,
};

char legNr[32] = {
  0,
};
char legZ[32] = {
  0,
};
char legX[32] = {
  0,
};
char legY[32] = {
  0,
};

char apply[32] = {
  0,
};

//variables for IK calculations
const int L1 = 25;//hip servo arm length
const int L2 = 40;//femur servo arm length
const int L3 = 60;//tibia servo arm length

const int X_MOVE_DIST = 20;
const int Y_MOVE_DIST = 20;
const int Z_MOVE_DIST = 20;
int MOVESTEP = 10;
int ticksPerStep = 3;
int cameraRotationAngle = 90;

int legRotVers[4][3] = 
{
  {-1,  -1, 1},
  {-1,  -1, 1},
  { -1,  1, -1},
  { -1,  1, -1}
};

struct legAngles 
{
      int hip;
      int femur;
      int tibia;
};

#define SPEED_LOW 0.1 //speed low move duration in mm/s
#define SPEED_HI 10 //speed fast move duration in mm/s
float MOVE_SPEED = 0.3;
#define MIN_STEP 1
#define MAX_STEP 50


legAngles computeAnglesForLeg(int legNo, int tipXp, int tipYp, int tipZp)
{
    // Serial.println("Entered computeAnglesForLeg");
    //       Serial.print("Move leg#:"); Serial.print(String(legNo)); 
    //       Serial.print(" to X:"); Serial.print(tipXp);
    //       Serial.print(", Y:"); Serial.print(tipYp);
    //       Serial.print(", Z:"); Serial.println(tipZp);

          double D = 0;
          double C = 0;

          double theta1 = 0;
          double theta2 = 0;
          double theta3 = 0;

          double alpha = 0;
          double beta = 0;
          double delta = 0;

          int femurOffset = 90;
          int tibiaOffset = 90;
          int hipOffset = 0;

          int hipAngle = 0;
          int femurAngle = 0;
          int tibiaAngle = 0;

          int Xp = tipXp;
          int Yp = tipYp;
          int Zp = tipZp;

          //need to switch X with Y as the axes are rotated in the model where the angles are computed
          int hold_my_var = Yp;
          Yp = Xp;
          Xp = hold_my_var;

          D = sqrt(Xp*Xp + Yp*Yp);
          C = sqrt(L1*L1 + D*D);

          theta1 = atan(D/L1) + asin(Zp/C);
          if (isnan(theta1))
          {
            theta1 = atan(D/L1) + acos(Yp/C);
          }
          alpha = asin(Yp/D);
          beta = acos((L3*L3 + D*D - L2*L2)/(2*L3*D));
          delta = acos((L2*L2 + D*D - L3*L3)/(2*L2*D));
          theta2 = alpha - delta;
          theta3 = alpha + beta;
          
          // Serial.println("L1: " + String(L1) + "; L2: " + String(L2) + "; L3: " + String(L3) + "; C: " + String(C) + "; D: " + String(D));
          // Serial.println("atan(D/L1): " + String(atan(D/L1)) + " asin(Zp/C): " + String(asin(Zp/C)));
          // Serial.println("theta1: " + String(theta1*180/PI) + "deg; theta2: " + String(theta2*180/PI) + "deg; theta3: " + String(theta3*180/PI) + "deg");

          hipAngle = round(hipOffset + theta1*180/PI);
          if (hipAngle < 0 ){hipAngle = 0;}
          if (hipAngle > 180){hipAngle = 180;}

          femurAngle = round(femurOffset + theta2*180/PI);
          if (femurAngle < 0 ){femurAngle = 0;}
          if (femurAngle > 180){femurAngle = 180;}
          
          tibiaAngle = round(tibiaOffset + theta3*180/PI) - femurAngle;
          if (tibiaAngle < 0 ){tibiaAngle = 0;}
          if (tibiaAngle > 180){tibiaAngle = 180;}

          // Serial.println("HipAngle: " + String(hipAngle) + "deg; FemurAngle: " + String(femurAngle) + "deg; TibiaAngle: " + String(tibiaAngle) + "deg");

          if (legRotVers[legNo - 1][0] == -1){hipAngle = 180 - abs(hipAngle);}
          if (legRotVers[legNo - 1][1] == -1){femurAngle = 180 - abs(femurAngle);}
          if (legRotVers[legNo - 1][2] == -1){tibiaAngle = 180 - abs(tibiaAngle);}
          
    //       Serial.println("HipAngle: " + String(hipAngle) + "deg; FemurAngle: " + String(femurAngle) + "deg; TibiaAngle: " + String(tibiaAngle) + "deg");

    // Serial.println("Exiting computeAnglesForLeg");

          return {hipAngle, femurAngle, tibiaAngle};
}






#define HTTPD_DEFAULT_CONFIG_demo() \
  { \
    .task_priority = tskIDLE_PRIORITY + 5, \
    .stack_size = 8192, \
    .server_port = 80, \
    .ctrl_port = 32768, \
    .max_open_sockets = 13, \
    .max_uri_handlers = 255, \
    .max_resp_headers = 255, \
    .backlog_conn = 5, \
    .lru_purge_enable = false, \
    .recv_wait_timeout = 5, \
    .send_wait_timeout = 5, \
    .global_user_ctx = NULL, \
    .global_user_ctx_free_fn = NULL, \
    .global_transport_ctx = NULL, \
    .global_transport_ctx_free_fn = NULL, \
    .open_fn = NULL, \
    .close_fn = NULL, \
    .uri_match_fn = NULL \
  }

typedef struct
{
  size_t size;   // number of values used for filtering
  size_t index;  // current value index
  size_t count;  // value count
  int sum;
  int *values;  // array to be filled with values
} ra_filter_t;

typedef struct
{
  httpd_req_t *req;
  size_t len;
} jpg_chunking_t;

#define PART_BOUNDARY "123456789000000000000987654321"
static const char *_STREAM_CONTENT_TYPE = "multipart/x-mixed-replace;boundary=" PART_BOUNDARY;
static const char *_STREAM_BOUNDARY = "\r\n--" PART_BOUNDARY "\r\n";
static const char *_STREAM_PART = "Content-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n";

static ra_filter_t ra_filter;
httpd_handle_t stream_httpd = NULL;
httpd_handle_t camera_httpd = NULL;

static ra_filter_t *ra_filter_init(ra_filter_t *filter, size_t sample_size) {
  memset(filter, 0, sizeof(ra_filter_t));

  filter->values = (int *)malloc(sample_size * sizeof(int));
  if (!filter->values) {
    return NULL;
  }
  memset(filter->values, 0, sample_size * sizeof(int));

  filter->size = sample_size;
  return filter;
}

static int ra_filter_run(ra_filter_t *filter, int value) {
  if (!filter->values) {
    return value;
  }
  filter->sum -= filter->values[filter->index];
  filter->values[filter->index] = value;
  filter->sum += filter->values[filter->index];
  filter->index++;
  filter->index = filter->index % filter->size;
  if (filter->count < filter->size) {
    filter->count++;
  }
  return filter->sum / filter->count;
}

static size_t jpg_encode_stream(void *arg, size_t index, const void *data, size_t len) {
  jpg_chunking_t *j = (jpg_chunking_t *)arg;
  if (!index) {
    j->len = 0;
  }
  if (httpd_resp_send_chunk(j->req, (const char *)data, len) != ESP_OK) {
    return 0;
  }
  j->len += len;
  return len;
}

static esp_err_t capture_handler(httpd_req_t *req) {
  camera_fb_t *fb = NULL;
  esp_err_t res = ESP_OK;
  int64_t fr_start = esp_timer_get_time();

  fb = esp_camera_fb_get();
  if (!fb) {
    Serial.printf("Camera capture failed");
    httpd_resp_send_500(req);

    return ESP_FAIL;
  }

  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Content-Disposition", "inline; filename=capture.jpg");

  size_t fb_len = 0;
  if (fb->format == PIXFORMAT_JPEG) {
    fb_len = fb->len;
    res = httpd_resp_send(req, (const char *)fb->buf, fb->len);
  } else {
    jpg_chunking_t jchunk = { req, 0 };
    res = frame2jpg_cb(fb, 80, jpg_encode_stream, &jchunk) ? ESP_OK : ESP_FAIL;
    // res = frame2jpg_cb(fb, 50, jpg_encode_stream, &jchunk) ? ESP_OK : ESP_FAIL;
    httpd_resp_send_chunk(req, NULL, 0);
    fb_len = jchunk.len;
  }
  esp_camera_fb_return(fb);
  int64_t fr_end = esp_timer_get_time();
  // Serial.printf("JPG: %uB %ums", (uint32_t)(fb_len), (uint32_t)((fr_end - fr_start) / 1000));
  return res;
}

static esp_err_t stream_handler(httpd_req_t *req) {
  camera_fb_t *fb = NULL;
  esp_err_t res = ESP_OK;
  size_t _jpg_buf_len = 0;
  uint8_t *_jpg_buf = NULL;
  char *part_buf[64];

  static int64_t last_frame = 0;
  if (!last_frame) {
    last_frame = esp_timer_get_time();
  }

  res = httpd_resp_set_type(req, _STREAM_CONTENT_TYPE);
  if (res != ESP_OK) {
    return res;
  }


  while (true) 
  {
      fb = esp_camera_fb_get();
      
      if (!fb) 
      {
        Serial.printf("Camera capture failed");
        res = ESP_FAIL;
      } 
      else 
      {
        if (fb->format != PIXFORMAT_JPEG) 
        {
          bool jpeg_converted = frame2jpg(fb, 80, &_jpg_buf, &_jpg_buf_len);
          esp_camera_fb_return(fb);
          fb = NULL;
          if (!jpeg_converted) 
          {
            Serial.printf("JPEG compression failed");
            res = ESP_FAIL;
          }
        } 
        else 
        {
          _jpg_buf_len = fb->len;
          _jpg_buf = fb->buf;
        }
      }
    
      if (res == ESP_OK) 
      {
        size_t hlen = snprintf((char *)part_buf, 64, _STREAM_PART, _jpg_buf_len);
        res = httpd_resp_send_chunk(req, (const char *)part_buf, hlen);
      }
      if (res == ESP_OK) 
      {
        res = httpd_resp_send_chunk(req, (const char *)_jpg_buf, _jpg_buf_len);
      }
    
      if (res == ESP_OK) 
      {
        res = httpd_resp_send_chunk(req, _STREAM_BOUNDARY, strlen(_STREAM_BOUNDARY));
      }

      if (fb) 
      {
        esp_camera_fb_return(fb);
        fb = NULL;
        _jpg_buf = NULL;
      } 
      else if (_jpg_buf) 
      {
        free(_jpg_buf);
        _jpg_buf = NULL;
      }
      if (res != ESP_OK) 
      {
        break;
      }
    
    
    int64_t fr_end = esp_timer_get_time();
    int64_t frame_time = fr_end - last_frame;
    last_frame = fr_end;
    frame_time /= 1000;
    uint32_t avg_frame_time = ra_filter_run(&ra_filter, frame_time);
  }

  last_frame = 0;
  return res;
}

static esp_err_t cmd_handler(httpd_req_t *req) {
  char *buf;
  size_t buf_len;
  char variable[32] = {
    0,
  };
  char value[32] = {
    0,
  };

  buf_len = httpd_req_get_url_query_len(req) + 1;
  if (buf_len > 1) {
    buf = (char *)malloc(buf_len);
    if (!buf) {
      httpd_resp_send_500(req);
      return ESP_FAIL;
    }
    if (httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) {
      if (httpd_query_key_value(buf, "var", variable, sizeof(variable)) == ESP_OK && httpd_query_key_value(buf, "val", value, sizeof(value)) == ESP_OK) {
      } else {
        free(buf);
        httpd_resp_send_404(req);
        return ESP_FAIL;
      }
    } else {
      free(buf);
      httpd_resp_send_404(req);
      return ESP_FAIL;
    }
    free(buf);
  } else {
    httpd_resp_send_404(req);
    return ESP_FAIL;
  }
  
  int val = atoi(value);
  sensor_t *s = esp_camera_sensor_get();
  int res = 0;

  if (!strcmp(variable, "framesize")) {
    if (s->pixformat == PIXFORMAT_JPEG)
      res = s->set_framesize(s, (framesize_t)val);
  } else if (!strcmp(variable, "quality"))
    res = s->set_quality(s, val);
  else if (!strcmp(variable, "contrast"))
    res = s->set_contrast(s, val);
  else if (!strcmp(variable, "brightness"))
    res = s->set_brightness(s, val);
  else if (!strcmp(variable, "saturation"))
    res = s->set_saturation(s, val);
  else if (!strcmp(variable, "gainceiling"))
    res = s->set_gainceiling(s, (gainceiling_t)val);
  else if (!strcmp(variable, "colorbar"))
    res = s->set_colorbar(s, val);
  else if (!strcmp(variable, "awb"))
    res = s->set_whitebal(s, val);
  else if (!strcmp(variable, "agc"))
    res = s->set_gain_ctrl(s, val);
  else if (!strcmp(variable, "aec"))
    res = s->set_exposure_ctrl(s, val);
  else if (!strcmp(variable, "hmirror"))
    res = s->set_hmirror(s, val);
  else if (!strcmp(variable, "vflip"))
    res = s->set_vflip(s, val);
  else if (!strcmp(variable, "awb_gain"))
    res = s->set_awb_gain(s, val);
  else if (!strcmp(variable, "agc_gain"))
    res = s->set_agc_gain(s, val);
  else if (!strcmp(variable, "aec_value"))
    res = s->set_aec_value(s, val);
  else if (!strcmp(variable, "aec2"))
    res = s->set_aec2(s, val);
  else if (!strcmp(variable, "dcw"))
    res = s->set_dcw(s, val);
  else if (!strcmp(variable, "bpc"))
    res = s->set_bpc(s, val);
  else if (!strcmp(variable, "wpc"))
    res = s->set_wpc(s, val);
  else if (!strcmp(variable, "raw_gma"))
    res = s->set_raw_gma(s, val);
  else if (!strcmp(variable, "lenc"))
    res = s->set_lenc(s, val);
  else if (!strcmp(variable, "special_effect"))
    res = s->set_special_effect(s, val);
  else if (!strcmp(variable, "wb_mode"))
    res = s->set_wb_mode(s, val);
  else if (!strcmp(variable, "ae_level"))
    res = s->set_ae_level(s, val);
  else {
    res = -1;
  }

  if (res) {
    return httpd_resp_send_500(req);
  }
}


static esp_err_t ml_handler(httpd_req_t *req) {
  char *buf;
  size_t buf_len;

  buf_len = httpd_req_get_url_query_len(req) + 1;
  if (buf_len > 1) {
    buf = (char *)malloc(buf_len);
    if (!buf) {
      httpd_resp_send_500(req);
      return ESP_FAIL;
    }
    if (httpd_req_get_url_query_str(req, buf, buf_len) == ESP_OK) 
    {
      // Serial.print("req buf: "); Serial.println(buf);
      if (httpd_query_key_value(buf, "leg", legNr, sizeof(legNr)) == ESP_OK)
      {
        Serial.print("legNr: "); Serial.println(legNr);
      }
      else
      if (httpd_query_key_value(buf, "x", legX, sizeof(legX)) == ESP_OK)
      {
        Serial.print("legX: "); Serial.println(legX);
        // delay(10);
        // newCmd = "ML";          
      }
      else
      if (httpd_query_key_value(buf, "y", legY, sizeof(legY)) == ESP_OK)
      {
        Serial.print("legY: "); Serial.println(legY);
        // delay(10);
        // newCmd = "ML";          
      }
      else
      if (httpd_query_key_value(buf, "z", legZ, sizeof(legZ)) == ESP_OK)
      {
        Serial.print("legZ: "); Serial.println(legZ);
        // delay(10);
        // newCmd = "ML";          
      }
      else
      if (httpd_query_key_value(buf, "sp", legMvSpd, sizeof(legMvSpd)) == ESP_OK)
      {
        // Serial.print("legMvSpd: "); Serial.println(legMvSpd);
        delay(50);
        newCmd = "SP";          
      }
      else
      if (httpd_query_key_value(buf, "sl", legMoveStep, sizeof(legMoveStep)) == ESP_OK)
      {
        // Serial.print("legMoveStep: "); Serial.println(legMoveStep);
        delay(50);
        newCmd = "SL";          
      }
      else
      if (httpd_query_key_value(buf, "tk", ticksPerStepStr, sizeof(ticksPerStepStr)) == ESP_OK)
      {
        // Serial.print("ticksPerStepStr: "); Serial.println(ticksPerStepStr);
        delay(50);
        newCmd = "TK";          
      }
      else
      if (httpd_query_key_value(buf, "ms", legMvSwitch, sizeof(legMvSwitch)) == ESP_OK)
      {
        // Serial.print("legMvSwitch: "); Serial.println(legMvSwitch);
        delay(50);
        newCmd = "MS";          
      }
      else
      if (httpd_query_key_value(buf, "im", useIMUSwitch, sizeof(useIMUSwitch)) == ESP_OK)
      {
        // Serial.print("useIMUSwitch: "); Serial.println(useIMUSwitch);
        delay(50);
        newCmd = "IM";          
      }
      else
      if (httpd_query_key_value(buf, "gs", gaitModeSwitch, sizeof(gaitModeSwitch)) == ESP_OK)
      {
        // Serial.print("gaitModeSwitch: "); Serial.println(gaitModeSwitch);
        delay(50);
        newCmd = "GS";          
      }
      else
      if (httpd_query_key_value(buf, "ts", turnModeSwitch, sizeof(turnModeSwitch)) == ESP_OK)
      {
        Serial.print("turnModeSwitch: "); Serial.println(turnModeSwitch);
        delay(50);
        newCmd = "TS";          
      }
      else
      if (httpd_query_key_value(buf, "stpl", stepLeftSwitch, sizeof(stepLeftSwitch)) == ESP_OK)
      {
        // Serial.print("stepLeftSwitch: "); Serial.println(stepLeftSwitch);
        delay(50);
        newCmd = "STPL";          
      }
      else
      if (httpd_query_key_value(buf, "stpr", stepRightSwitch, sizeof(stepRightSwitch)) == ESP_OK)
      {
        // Serial.print("stepRightSwitch: "); Serial.println(stepRightSwitch);
        delay(50);
        newCmd = "STPR";          
      }
      else
      if (httpd_query_key_value(buf, "apply", apply, sizeof(apply)) == ESP_OK)
      {
        // Serial.print("Apply: "); Serial.println(apply);
        if (String(apply) == "Y")
        {
          newCmd = "ML";          
        }
      }
      else 
      {
        free(buf);
        httpd_resp_send_404(req);
        return ESP_FAIL;
      }
    } else {
      free(buf);
      httpd_resp_send_404(req);
      return ESP_FAIL;
    }
    free(buf);
  } else {
    httpd_resp_send_404(req);
    return ESP_FAIL;
  }


  int res = 0;


  if (res) {
    return httpd_resp_send_500(req);
  }

  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, NULL, 0);
}



static esp_err_t status_handler(httpd_req_t *req) {
  static char json_response[1024];

  sensor_t *s = esp_camera_sensor_get();
  char *p = json_response;
  *p++ = '{';

  p += sprintf(p, "\"framesize\":%u,", s->status.framesize);
  p += sprintf(p, "\"quality\":%u,", s->status.quality);
  p += sprintf(p, "\"brightness\":%d,", s->status.brightness);
  p += sprintf(p, "\"contrast\":%d,", s->status.contrast);
  p += sprintf(p, "\"saturation\":%d,", s->status.saturation);
  p += sprintf(p, "\"special_effect\":%u,", s->status.special_effect);
  p += sprintf(p, "\"wb_mode\":%u,", s->status.wb_mode);
  p += sprintf(p, "\"awb\":%u,", s->status.awb);
  p += sprintf(p, "\"awb_gain\":%u,", s->status.awb_gain);
  p += sprintf(p, "\"aec\":%u,", s->status.aec);
  p += sprintf(p, "\"aec2\":%u,", s->status.aec2);
  p += sprintf(p, "\"ae_level\":%d,", s->status.ae_level);
  p += sprintf(p, "\"aec_value\":%u,", s->status.aec_value);
  p += sprintf(p, "\"agc\":%u,", s->status.agc);
  p += sprintf(p, "\"agc_gain\":%u,", s->status.agc_gain);
  p += sprintf(p, "\"gainceiling\":%u,", s->status.gainceiling);
  p += sprintf(p, "\"bpc\":%u,", s->status.bpc);
  p += sprintf(p, "\"wpc\":%u,", s->status.wpc);
  p += sprintf(p, "\"raw_gma\":%u,", s->status.raw_gma);
  p += sprintf(p, "\"lenc\":%u,", s->status.lenc);
  p += sprintf(p, "\"hmirror\":%u,", s->status.hmirror);
  p += sprintf(p, "\"dcw\":%u,", s->status.dcw);
  p += sprintf(p, "\"colorbar\":%u", s->status.colorbar);
  *p++ = '}';
  *p++ = 0;
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, json_response, strlen(json_response));
}

static esp_err_t index_handler(httpd_req_t *req) {
  httpd_resp_set_type(req, "text/html");
  String page = "";

  page += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0\">\n";
  page += "<script>var xhttp = new XMLHttpRequest();</script>";
  page += "<script>function getsend(arg) { xhttp.open('GET', arg +'?' + new Date().getTime(), true); xhttp.send() } </script>";
  page += "<script>function sendargs(cmd,args) { xhttp.open('GET', cmd +'?' + args, true); xhttp.send() } </script>";
  page += "<script>function rotateImage() {getsend('rotate');location.reload();}</script>";

  page += "";
  // page += "<p align=center><b>" + pageTitle + "</b></p>";
  page += "<p align=center><b>" + pageTitle + "</b><br>";

  //for ESP32-CAM
  // page += "<p align=center><IMG SRC='http://" + WiFiAddr + ":81/stream' style='height:240px;width:320px;transform:rotate(180deg);'></p>";
  
  //for ESP32-WROVER board
  // page += "<p align=center><IMG SRC='http://" + WiFiAddr + ":81/stream' style='height:320px;width:240px;transform:rotate(90deg);'></p>";
  // page += "<IMG SRC='http://" + WiFiAddr + ":81/stream' style='height:320px;width:240px;transform:rotate(90deg);'></p>";
  page += "<IMG SRC='http://" + WiFiAddr + ":81/stream' style='height:240px;width:240px;transform:rotate(" + cameraRotationAngle + "deg)'><br>";
  // page += "<button style=text-align:center;background-color:lightgrey;width:100px;height:25px onmousedown=getsend('rotate') ontouchend=getsend('rotate')><b>Rotate Image</b></button></p>";
  page += "<button style=text-align:center;background-color:lightgrey;width:200px;height:25px onmousedown=rotateImage() ontouchend=rotateImage()><b>Rotate Image by 90 deg</b></button></p>";

  page += "<p align=center>";

  // page += "<script>window.setInterval(function() {reloadImg()}, 1000);function reloadImg() {document.getElementById('imgFrame').contentWindow.location.reload(true);}</script>";
  // page += "<iframe src=\"http://" + WiFiAddr + "/capture\" style=\"transform:rotate(180deg);visibility:hidden;frameborder:0;border:0;border-style:none;width:320px;height:240px;scrolling:no;overflow:hidden;align-items:center;justify-content:center;font-size:24px\" onload=\"this.style.visibility = 'visible'\" id=\"imgFrame\"></iframe>";
  // page += "<br><br>";

  // page += "<br>";
  page += "<script>window.setInterval(function() {reloadPingIFrame()}, 1000);function reloadPingIFrame() {document.getElementById('pingResp').contentWindow.location.reload(true);}</script>";
  page += "<iframe src=\"http://" + WiFiAddr + "/ping\" style=\"display:block;frameborder:1;border:1;border-style:solid;width:320px;height:35px;scrolling:no;overflow:hidden;align-items:center;justify-content:center;font-size:24px\" id=\"pingResp\"></iframe>";
  // page += "<br>";

  page += "<p align=center>";   
  page += "<button style=text-align:center;background-color:#2838E6;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('left') ontouchend=getsend('left')><b>Turn<br>Left</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#2838E6;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('forward') ontouchend=getsend('forward')><b>Step<br>Forward</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#2838E6;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('right') ontouchend=getsend('right')><b>Turn<br>Right</b></button>";
  page += "</p>";
  page += "<p align=center>";
  page += "<button style=text-align:center;background-color:#2838E6;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('stepleft') ontouchend=getsend('stepleft')><b>Step<br>Left</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#2838E6;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('back') ontouchend=getsend('back')><b>Step<br>Backward</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#2838E6;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('stepright') ontouchend=getsend('stepright')><b>Step<br>Right</b></button>";
  page += "</p>";

  page += "<p align=center>";
  page += "<button style=text-align:center;background-color:#258A69;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('lookleft') ontouchend=getsend('lookleft')><b>Look<br>Left</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#258A69;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('lookup') ontouchend=getsend('lookup')><b>Look<br>Up</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#258A69;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('lookright') ontouchend=getsend('lookright')><b>Look<br>Right</b></button><br><br>";
  page += "<button style=text-align:center;background-color:#258A69;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('rollleft') ontouchend=getsend('rollleft')><b>Lean<br>Left</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#258A69;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('lookdown') ontouchend=getsend('lookdown')><b>Look<br>Down</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#258A69;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('rollright') ontouchend=getsend('rollright')><b>Lean<br>Right</b></button><br><br>";

  page += "<button style=text-align:center;background-color:#822020;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('shiftleft') ontouchend=getsend('shiftleft')><b>Shift<br>Left</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#822020;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('shiftfwd') ontouchend=getsend('shiftfwd')><b>Shift<br>Forward</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#822020;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('shiftright') ontouchend=getsend('shiftright')><b>Shift<br>Right</b></button><br><br>";
  page += "<button style=text-align:center;background-color:#822020;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('shiftup') ontouchend=getsend('shiftup')><b>Shift<br>Upward</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#822020;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('shiftback') ontouchend=getsend('shiftback')><b>Shift<br>Backward</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#822020;color:#EEEEEE;width:100px;height:35px onmousedown=getsend('shiftdown') ontouchend=getsend('shiftdown')><b>Shift<br>Downward</b></button>&nbsp;";
  page += "<br>";

  page += "</p>";





  page += "<p align=center>";
  page += "<button style=text-align:center;background-color:#00CC00;width:75px;height:35px onmousedown=getsend('start') ontouchend=getsend('start')><b>Start<br>Moving</b></button>&nbsp;";
  page += "<button style=text-align:center;background-color:#CC0000;color:#EEEEEE;width:75px;height:35px onmousedown=getsend('stop') ontouchend=getsend('stop')><b>Stop<br>Moving</b></button>&nbsp;";
  page += "<button style=background-color:#00EE00;width:75px;height:35px; onmousedown=getsend('sonaron') ontouchend=getsend('sonaron')><b>Sonar<br>ON</b></button>&nbsp;";
  page += "<button style=background-color:#DD0000;color:#EEEEEE;width:75px;height:35px; onmousedown=getsend('sonaroff') ontouchend=getsend('sonaroff')><b>Sonar<br>OFF</b></button>&nbsp;";
  page += "<br>";
  // page += "<br>";
  // page += "<button style=background-color:lightgrey;width:90px;height:40px onmousedown=getsend('ping') ontouchend=getsend('ping')><b>Ping</b></button>&nbsp;";
  page += "</p>";

  page += "<p align=center>";
  page += "<button style=background-color:#00DD00;width:75px;height:35px onmousedown=getsend('center') ontouchend=getsend('center')><b>Stand<br>Up</b></button>&nbsp;";
  // page += "<button style=background-color:#00DD00;width:25px;height:35px onmousedown=getsend('center') ontouchend=getsend('center')><b>W<br>M</b></button>&nbsp;";
  page += "</p>";
  page += "<p align=center>";
  // page += "<br>";
  page += "<button style=background-color:#DD1100;color=#EEFFEE;width:75px;height:35px; onmousedown=getsend('calibrate') ontouchend=getsend('calibrate')><b>Center<br>Servos</b></button>&nbsp;";
  page += "<button style=background-color:#AABB00;width:75px;height:35px; onmousedown=getsend('sit') ontouchend=getsend('sit')><b>Sit<br>Down</b></button>&nbsp;";
  page += "<button style=background-color:#EEEE00;width:75px;height:35px; onmousedown=getsend('crouch') ontouchend=getsend('crouch')><b>Go<br>Prone</b></button>&nbsp;";
  page += "<button style=background-color:#0000EE;color:#EEEEEE;width:75px;height:35px; onmousedown=getsend('stand') ontouchend=getsend('stand')><b>Stand<br>Tall</b></button>&nbsp;";
  page += "</p>";

  // page += "<p align=center>";
  // // page += "<br>";
  // page += "<button style=background-color:yellow;width:75px;height:35px onmousedown=getsend('ledon') ontouchend=getsend('ledon') ontouchend=getsend('ledon')><b>Light<br>ON</b></button>&nbsp;";
  // page += "<button style=background-color:yellow;width:75px;height:35px onmousedown=getsend('ledoff') ontouchend=getsend('ledoff')><b>Light<br>OFF</b></button>&nbsp;";

  // // page += "<button style=background-color:lightgrey;width:75px;height:35px onmousedown=getsend('speedlow') ontouchend=getsend('speedlow')><b>Low T<br>speed</b></button>&nbsp;";
  // // page += "<button style=background-color:lightgrey;width:75px;height:35px onmousedown=getsend('speedhigh') ontouchend=getsend('speedhigh')><b>High T<br>speed</b></button>";
  // // page += "<button style=background-color:yellow;width:75px;height:35px onmousedown=getsend('ping') ontouchend=getsend('ping')><b>Ping</b></button>&nbsp;<br>";

  // page += "</p>";

  page += "<p align=center>";
  page += "<label for=\"leg\">Leg:</label><select id=\"leg\" name=\"leg\"><option value=\"-1\">None</option><option value=\"1\">Front left (#1)</option><option value=\"2\">Rear left (#2)</option><option value=\"3\">Front right (#3)</option><option value=\"4\">Rear right (#4)</option></select>";
  page += "<script>var dropdown_leg = document.getElementById(\"leg\");dropdown_leg.oninput = function(){sendargs('ml','leg=' + this.value)}</script>";
  page += "&nbsp";
  page += "<button style=background-color:yellow;width:100px;height:35px onmousedown=sendargs('ml','apply=Y') ontouchend=sendargs('ml','apply=Y')><b>Move leg</b></button>&nbsp;";
  page += "</p>";

  page += "<p align=center>";
  page += "<script>window.setInterval(function() {reloadLegPosIFrame()}, 1000);function reloadLegPosIFrame() {document.getElementById('legPos').contentWindow.location.reload(true);}</script>";
  page += "<iframe src=\"http://" + WiFiAddr + "/legpos\" style=\"display:block;frameborder:1;border:1;border-style:solid;width:320px;height:35px;scrolling:no;overflow:hidden;align-items:center;justify-content:center;font-size:24px\" id=\"legPos\"></iframe>";
  page += "</p>";


  page += "<script>function increaseSlider(slider) {document.getElementById(slider).value = parseInt(document.getElementById(slider).value) + 1; document.getElementById(slider + '_label').innerHTML = document.getElementById(slider).value;} </script>";
  page += "<script>function decreaseSlider(slider) {document.getElementById(slider).value = parseInt(document.getElementById(slider).value) - 1; document.getElementById(slider + '_label').innerHTML = document.getElementById(slider).value;} </script>";
  page += "<script>function decreaseLegX(){decreaseSlider('legX');sendargs('ml','x=' + document.getElementById('legX').value)}</script>";
  page += "<script>function increaseLegX(){increaseSlider('legX');sendargs('ml','x=' + document.getElementById('legX').value)}</script>";
  page += "<script>function decreaseLegY(){decreaseSlider('legY');sendargs('ml','y=' + document.getElementById('legY').value)}</script>";
  page += "<script>function increaseLegY(){increaseSlider('legY');sendargs('ml','y=' + document.getElementById('legY').value)}</script>";
  page += "<script>function decreaseLegZ(){decreaseSlider('legZ');sendargs('ml','z=' + document.getElementById('legZ').value)}</script>";
  page += "<script>function increaseLegZ(){increaseSlider('legZ');sendargs('ml','z=' + document.getElementById('legZ').value)}</script>";
  page += "<p align=center>";
  page += "Leg X:&nbsp;<span id=\"legX_label\"></span>&nbsp;";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=decreaseLegX() ontouchend=decreaseLegX()>-</button>";
  page += "<input align=\"center\" type=\"range\" id=\"legX\" name=\"legX\" min=\"" + String(-X_MOVE_DIST) + "\" max=\"" + String(X_MOVE_DIST) + "\" step=\"1\" value=\"0\"/>";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=increaseLegX() ontouchend=increaseLegX()>+</button>";
  page += "&nbsp;&nbsp;<br>";
  page += "<script>";
  page += "var slider_legX = document.getElementById(\"legX\");";
  page += "var output_legX = document.getElementById(\"legX_label\");";
  page += "output_legX.innerHTML = slider_legX.value;";
  page += "slider_legX.oninput = function()";
  page += "{output_legX.innerHTML = this.value;sendargs('ml','x=' + this.value)}</script>";

  page += "Leg Y:&nbsp;<span id=\"legY_label\"></span>&nbsp;";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=decreaseLegY() ontouchend=decreaseLegY()>-</button>";
  page += "<input align=\"center\" type=\"range\" id=\"legY\" name=\"legY\" min=\"" + String(-Y_MOVE_DIST) + "\" max=\"" + String(X_MOVE_DIST) + "\" step=\"1\" value=\"0\"/>";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=increaseLegY() ontouchend=increaseLegY()>+</button>";
  page += "&nbsp;&nbsp;<br>";
  page += "<script>";
  page += "var slider_legY = document.getElementById(\"legY\");";
  page+= "var output_legY = document.getElementById(\"legY_label\");";
  page += "output_legY.innerHTML = slider_legY.value;";
  page += "slider_legY.oninput = function()";
  page += "{output_legY.innerHTML = this.value;sendargs('ml','y=' + this.value)}</script>";

  page += "Leg Z:&nbsp;<span id=\"legZ_label\"></span>&nbsp;";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=decreaseLegZ() ontouchend=decreaseLegZ()>-</button>";
  page += "<input align=\"center\" type=\"range\" id=\"legZ\" name=\"legZ\" min=\"" + String(-Z_MOVE_DIST) + "\" max=\"" + String(Z_MOVE_DIST) + "\" step=\"1\" value=\"0\"/>";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=increaseLegZ() ontouchend=increaseLegZ()>+</button>";
  page += "&nbsp;&nbsp;<br>";
  page += "<script>";
  page += "var slider_legZ = document.getElementById(\"legZ\");";
  page+= "var output_legZ = document.getElementById(\"legZ_label\");";
  page += "output_legZ.innerHTML = slider_legZ.value;";
  page += "slider_legZ.oninput = function()";
  page += "{output_legZ.innerHTML = this.value;sendargs('ml','z=' + this.value)}</script>";

  page += "</p>";

  page += "<p align=center>";

  page += "<script>function increaseSliderFloat(slider) {document.getElementById(slider).value = parseFloat(document.getElementById(slider).value) + parseFloat(0.1); document.getElementById(slider + '_label').innerHTML = document.getElementById(slider).value;} </script>";
  page += "<script>function decreaseSliderFloat(slider) {document.getElementById(slider).value = parseFloat(document.getElementById(slider).value) - parseFloat(0.1); document.getElementById(slider + '_label').innerHTML = document.getElementById(slider).value;} </script>";
  
  page += "<script>function decreaselegMvSpd(){decreaseSliderFloat('legMvSpd');sendargs('ml','sp=' + document.getElementById('legMvSpd').value)}</script>";
  page += "<script>function increaselegMvSpd(){increaseSliderFloat('legMvSpd');sendargs('ml','sp=' + document.getElementById('legMvSpd').value)}</script>";

  page += "<script>function decreaselegMoveStep(){decreaseSlider('legMoveStep');sendargs('ml','sl=' + document.getElementById('legMoveStep').value)}</script>";
  page += "<script>function increaselegMoveStep(){increaseSlider('legMoveStep');sendargs('ml','sl=' + document.getElementById('legMoveStep').value)}</script>";

  page += "Leg move speed[mm/s]:&nbsp;<span id=\"legMvSpd_label\"></span>&nbsp;";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=decreaselegMvSpd() ontouchend=decreaselegMvSpd()>-</button>";
  page += "<input align=\"center\" type=\"range\" id=\"legMvSpd\" name=\"legMvSpd\" min=\"" + String(SPEED_LOW) + "\" max=\"" + String(SPEED_HI) + "\" step=\"0.1\" value=\"" + MOVE_SPEED + "\"/>";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=increaselegMvSpd() ontouchend=increaselegMvSpd()>+</button>";
  page += "&nbsp;&nbsp;<br>";
  page += "<script>";
  page += "var slider_legMvSpd = document.getElementById(\"legMvSpd\");";
  page += "var output_legMvSpd = document.getElementById(\"legMvSpd_label\");";
  page += "output_legMvSpd.innerHTML = slider_legMvSpd.value;";
  page += "slider_legMvSpd.oninput = function()";
  page += "{output_legMvSpd.innerHTML = this.value;sendargs('ml','sp=' + this.value)}</script>";

  page += "Leg step length[mm]:&nbsp;<span id=\"legMoveStep_label\"></span>&nbsp;";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=decreaselegMoveStep() ontouchend=decreaselegMoveStep()>-</button>";
  page += "<input align=\"center\" type=\"range\" id=\"legMoveStep\" name=\"legMoveStep\" min=\"" + String(MIN_STEP) + "\" max=\"" + String(MAX_STEP) + "\" step=\"1\" value=\"" + MOVESTEP + "\"/>";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=increaselegMoveStep() ontouchend=increaselegMoveStep()>+</button>";
  page += "&nbsp;&nbsp;<br>";
  page += "<script>";
  page += "var slider_legMoveStep = document.getElementById(\"legMoveStep\");";
  page+= "var output_legMoveStep = document.getElementById(\"legMoveStep_label\");";
  page += "output_legMoveStep.innerHTML = slider_legMoveStep.value;";
  page += "slider_legMoveStep.oninput = function()";
  page += "{output_legMoveStep.innerHTML = this.value;sendargs('ml','sl=' + this.value)}</script>";

  page += "<br>";
  page += "<input type=\"checkbox\" id=\"stepLeftSwitch\" name=\"stepLeftSwitch\" checked/><label for=\"stepLeftSwitch\" id=\"stepLeftSwitch_label\">Step with left front leg</label><br>";
  page += "<input type=\"checkbox\" id=\"stepRightSwitch\" name=\"stepRightSwitch\" checked/><label for=\"stepRightSwitch\" id=\"stepRightSwitch_label\">Step with right front leg</label>";
  page += "<script>";
  page += "var stepLeftSwitch_checkbox = document.getElementById(\"stepLeftSwitch\");";
  page += "stepLeftSwitch_checkbox.onclick = function()";
  page += "{sendargs('ml','stpl=' + stepLeftSwitch_checkbox.checked)};";
  page += "</script>";
  page += "<script>";
  page += "var stepRightSwitch_checkbox = document.getElementById(\"stepRightSwitch\");";
  page += "stepRightSwitch_checkbox.onclick = function()";
  page += "{sendargs('ml','stpr=' + stepRightSwitch_checkbox.checked)};";
  page += "</script>";
  page += "</p>";
  page += "<p align=center>";
  page += "<input type=\"checkbox\" id=\"legMoveSwitch\" name=\"legMoveSwitch\" checked/><label for=\"legMoveSwitch\" id=\"legMoveSwitch_label\">Translate legs to position</label>";
  page += "<script>";
  page += "var legMoveSwitch_checkbox = document.getElementById(\"legMoveSwitch\");";
  page += "var legMoveSwitch_checkbox_label = document.getElementById(\"legMoveSwitch_label\");";
  page += "legMoveSwitch_checkbox.onclick = function()";
  page += "{if (!legMoveSwitch_checkbox.checked){legMoveSwitch_checkbox_label.innerHTML = \"Switch directly to position\";}";
  page += "else{legMoveSwitch_checkbox_label.innerHTML = \"Translate legs to position\";};";
  page += "sendargs('ml','ms=' + legMoveSwitch_checkbox.checked)}</script>";

  if (hasIMUSensor)
  {
    page += "<br><input type=\"checkbox\" id=\"useIMUSwitch\" name=\"useIMUSwitch\" unchecked/><label for=\"useIMUSwitch\" id=\"useIMUSwitch_label\">DO NOT use IMU to stabilize</label>";
    page += "<script>";
    page += "var useIMUSwitch_checkbox = document.getElementById(\"useIMUSwitch\");";
    page += "var useIMUSwitch_checkbox_label = document.getElementById(\"useIMUSwitch_label\");";
    page += "useIMUSwitch_checkbox.onclick = function()";
    page += "{if (!useIMUSwitch_checkbox.checked){useIMUSwitch_checkbox_label.innerHTML = \"DO NOT use IMU to stabilize\";}";
    page += "else{useIMUSwitch_checkbox_label.innerHTML = \"Use IMU to stabilize\";};";
    page += "sendargs('ml','im=' + useIMUSwitch_checkbox.checked)}</script>";

    page += "<br><button style=background-color:#lightgrey;color:#000000;width:75px;height:35px; onmousedown=getsend('rstimu') ontouchend=getsend('rstimu')><b>Reset<br>IMU</b></button>&nbsp;";
  }

  page += "</p>";


  page += "<p align=center>";
  // page += "<label for=\"gait\">Gait:</label><select id=\"gait\" name=\"gait\"><option value=\"0\">Walk</option><option value=\"1\" selected>Trot</option><option value=\"2\">Gallop</option><option value=\"3\">Quick Walk</option></select>";
  page += "<label for=\"gait\">Walking Gait:</label><select id=\"gait\" name=\"gait\"><option value=\"1\">Trot</option><option value=\"2\" selected>Walk</option><option value=\"3\">Crawl</option></select>";
  page += "<script>var dropdown_gait = document.getElementById(\"gait\");dropdown_gait.onchange = function(){sendargs('ml','gs=' + this.value)}</script>";
  // page += "<input type=\"checkbox\" id=\"gaitModeSwitch\" name=\"gaitModeSwitch\" checked/><label for=\"gaitModeSwitch\" id=\"gaitModeSwitch_label\">Trot gait</label>";
  // page += "<script>";
  // page += "var gaitModeSwitch_checkbox = document.getElementById(\"gaitModeSwitch\");";
  // page += "var gaitModeSwitch_checkbox_label = document.getElementById(\"gaitModeSwitch_label\");";
  // page += "gaitModeSwitch_checkbox.onclick = function()";
  // page += "{if (gaitModeSwitch_checkbox.checked){gaitModeSwitch_checkbox_label.innerHTML = \"Trot gait\";}";
  // page += "else{gaitModeSwitch_checkbox_label.innerHTML = \"Gallop gait\";};";
  // page += "sendargs('ml','gs=' + gaitModeSwitch_checkbox.checked)}</script>";
  page += "</p>";

  page += "<p align=center>";
  page += "<label for=\"turn\">Turn gait:</label><select id=\"turn\" name=\"turn\"><option value=\"0\" selected>SQUARE</option><option value=\"1\">DIAGONAL</option></select>";
  page += "<script>var dropdown_turn = document.getElementById(\"turn\");dropdown_turn.onchange = function(){sendargs('ml','ts=' + this.value)}</script>";
  page += "</p>";

  page += "<p align=center>";
  page += "<button style=text-align:center;background-color:#00CC00;width:75px;height:55px onmousedown=getsend('trotstep') ontouchend=getsend('trotstep')><b>FWD<br>TROT<br>STEP</b></button>&nbsp;";
  page += "<br>";

  page += "<script>function decreaseNrTicks(){decreaseSlider('NrTicks');sendargs('ml','tk=' + document.getElementById('NrTicks').value)}</script>";
  page += "<script>function increaseNrTicks(){increaseSlider('NrTicks');sendargs('ml','tk=' + document.getElementById('NrTicks').value)}</script>";

  page += "Ticks Per Trot Step:&nbsp;<span id=\"NrTicks_label\"></span>&nbsp;";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=decreaseNrTicks() ontouchend=decreaseNrTicks()>-</button>";
  page += "<input align=\"center\" type=\"range\" id=\"NrTicks\" name=\"NrTicks\" min=\"" + String(1) + "\" max=\"" + String(10) + "\" step=\"1\" value=\"" + ticksPerStep + "\"/>";
  page += "<button style=background-color:#lightgrey;width:20px;height:20px; onmousedown=increaseNrTicks() ontouchend=increaseNrTicks()>+</button>";
  page += "&nbsp;&nbsp;<br>";
  page += "<script>";
  page += "var slider_NrTicks = document.getElementById(\"NrTicks\");";
  page += "var output_NrTicks = document.getElementById(\"NrTicks_label\");";
  page += "output_NrTicks.innerHTML = slider_NrTicks.value;";
  page += "slider_NrTicks.oninput = function()";
  page += "{output_NrTicks.innerHTML = this.value;sendargs('ml','tk=' + this.value)}</script>";

  page += "</p>";


  // page += "<p align=center>";
  // page += "<input type=\"checkbox\" id=\"gaitModeSwitch\" name=\"gaitModeSwitch\" checked/><label for=\"gaitModeSwitch\" id=\"gaitModeSwitch_label\">Trot gait</label>";
  // page += "<script>";
  // page += "var gaitModeSwitch_checkbox = document.getElementById(\"gaitModeSwitch\");";
  // page += "var gaitModeSwitch_checkbox_label = document.getElementById(\"gaitModeSwitch_label\");";
  // page += "gaitModeSwitch_checkbox.onclick = function()";
  // page += "{if (gaitModeSwitch_checkbox.checked){gaitModeSwitch_checkbox_label.innerHTML = \"Trot gait\";}";
  // page += "else{gaitModeSwitch_checkbox_label.innerHTML = \"Gallop gait\";};";
  // page += "sendargs('ml','gs=' + gaitModeSwitch_checkbox.checked)}</script>";
  // page += "</p>";

  page += "<br>";

  return httpd_resp_send(req, &page[0], strlen(&page[0]));
}

static esp_err_t calibrate_handler(httpd_req_t *req) {
  txdata[1] = Calibrate;
  // Serial.write(txdata, 3);
  // Serial.println("CALIBRATE");
  newCmd = "CALIBRATE";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

static esp_err_t sit_handler(httpd_req_t *req) {
  txdata[1] = Sit;
  // Serial.write(txdata, 3);
  // Serial.println("SIT");
  newCmd = "SIT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}


static esp_err_t shiftfwd_handler(httpd_req_t *req) {
  txdata[1] = Shift_Fwd;
  // Serial.write(txdata, 3);
  // Serial.println("SHIFT FWD");
  newCmd = "SHIFT FWD";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t shiftback_handler(httpd_req_t *req) {
  txdata[1] = Shift_Back;
  // Serial.write(txdata, 3);
  // Serial.println("SHIFT BACK");
  newCmd = "SHIFT BACK";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t shiftup_handler(httpd_req_t *req) {
  txdata[1] = Shift_Up;
  // Serial.write(txdata, 3);
  // Serial.println("SHIFT UP");
  newCmd = "SHIFT UP";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t shiftdown_handler(httpd_req_t *req) {
  txdata[1] = Shift_Down;
  // Serial.write(txdata, 3);
  // Serial.println("SHIFT DOWN");
  newCmd = "SHIFT DOWN";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t shiftleft_handler(httpd_req_t *req) {
  txdata[1] = Shift_Left;
  // Serial.write(txdata, 3);
  // Serial.println("SHIFT LEFT");
  newCmd = "SHIFT LEFT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t shiftright_handler(httpd_req_t *req) {
  txdata[1] = Shift_Right;
  // Serial.write(txdata, 3);
  // Serial.println("SHIFT RIGHT");
  newCmd = "SHIFT RIGHT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}



static esp_err_t lookup_handler(httpd_req_t *req) {
  txdata[1] = Look_Up;
  // Serial.write(txdata, 3);
  // Serial.println("LOOK UP");
  newCmd = "LOOK UP";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t lookdown_handler(httpd_req_t *req) {
  txdata[1] = Look_Down;
  // Serial.write(txdata, 3);
  // Serial.println("LOOK DOWN");
  newCmd = "LOOK DOWN";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t lookleft_handler(httpd_req_t *req) {
  txdata[1] = Look_Left;
  // Serial.write(txdata, 3);
  // Serial.println("LOOK LEFT");
  newCmd = "LOOK LEFT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t lookright_handler(httpd_req_t *req) {
  txdata[1] = Look_Right;
  // Serial.write(txdata, 3);
  // Serial.println("LOOK RIGHT");
  newCmd = "LOOK RIGHT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t rollleft_handler(httpd_req_t *req) {
  txdata[1] = Roll_Left;
  // Serial.write(txdata, 3);
  // Serial.println("ROLL LEFT");
  newCmd = "ROLL LEFT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t rollright_handler(httpd_req_t *req) {
  txdata[1] = Roll_Right;
  // Serial.write(txdata, 3);
  // Serial.println("ROLL RIGHT");
  newCmd = "ROLL RIGHT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}


static esp_err_t forward_handler(httpd_req_t *req) {
  txdata[1] = Forward;
  // Serial.write(txdata, 3);
  //Serial.println("FORWARD");
  newCmd = "FORWARD";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t back_handler(httpd_req_t *req) {
  txdata[1] = Backward;
  // Serial.write(txdata, 3);
  // Serial.println("BACKWARD");
  newCmd = "BACKWARD";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t left_handler(httpd_req_t *req) {
  txdata[1] = Turn_Left;
  // Serial.write(txdata, 3);
  // Serial.println("TURN LEFT");
  newCmd = "TURN LEFT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t right_handler(httpd_req_t *req) {
  txdata[1] = Turn_Right;
  // Serial.write(txdata, 3);
  // Serial.println("TURN RIGHT");
  newCmd = "TURN RIGHT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t start_handler(httpd_req_t *req) {
  txdata[1] = Start;
  // Serial.write(txdata, 3);
  // Serial.println("START MOVING");
  newCmd = "START MOVING";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t stop_handler(httpd_req_t *req) {
  txdata[1] = Stop;
  // Serial.write(txdata, 3);
  // Serial.println("STOP MOVING");
  newCmd = "STOP MOVING";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t ledon_handler(httpd_req_t *req) {
  digitalWrite(gpLed, HIGH);
  // Serial.println("LED ON");
  newCmd = "LED ON";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t ledoff_handler(httpd_req_t *req) {
  digitalWrite(gpLed, LOW);
  // Serial.println("LED OFF");
  newCmd = "LED OFF";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

//////////////////////////////new/////////////////////////////////
static esp_err_t sonaron_handler(httpd_req_t *req) {
  txdata[1] = SonarOn;
  // Serial.write(txdata, 3);
  // Serial.println("SONAR ON");
  sonar_flag = true;
  newCmd = "SONAR ON";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t sonaroff_handler(httpd_req_t *req) {
  txdata[1] = SonarOff;
  // Serial.write(txdata, 3);
  // Serial.println("SONAR OFF");
  sonar_flag = false;
  newCmd = "SONAR OFF";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t ping_handler(httpd_req_t *req) {
  txdata[1] = Ping;
  // Serial.write(txdata, 3);
  // Serial.println("PING");
  newCmd = "PING";
  httpd_resp_set_type(req, "text/html");

  String response;
  if (sonar_flag)
  {
    sprintf(rangeBfr, "%03d", range);
    String range_str = rangeBfr;
    response = "Distance: " + range_str + " cm";
  }
  else
  {
    response = "SONAR IS OFF";
  }


  return httpd_resp_send(req, response.c_str(), response.length());
}
static esp_err_t legpos_handler(httpd_req_t *req) {
  txdata[1] = Legpos;
  // Serial.write(txdata, 3);
  // Serial.println("LEGPOS");
  newCmd = "LEGPOS";
  httpd_resp_set_type(req, "text/html");

  String response;
  response = "Leg Nr=" + String(legNr_int) + "; X=" + String(legX_int) + "; Y=" + String(legY_int) + "; Z=" + String(legZ_int);

  return httpd_resp_send(req, response.c_str(), response.length());
}
static esp_err_t stepleft_handler(httpd_req_t *req) {
  txdata[1] = StepLeft;
  // Serial.write(txdata, 3);
  // Serial.println("STEP LEFT");
  newCmd = "STEP LEFT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t crouch_handler(httpd_req_t *req) {
  txdata[1] = Crouch;
  // Serial.write(txdata, 3);
  // Serial.println("CROUCH");
  newCmd = "CROUCH";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t stepright_handler(httpd_req_t *req) {
  txdata[1] = StepRight;
  // Serial.write(txdata, 3);
  // Serial.println("STEP RIGHT");
  newCmd = "STEP RIGHT";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t stand_handler(httpd_req_t *req) {
  txdata[1] = Stand;
  // Serial.write(txdata, 3);
  // Serial.println("STAND");
  newCmd = "STAND";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

static esp_err_t speedlow_handler(httpd_req_t *req) {
  txdata[1] = SpeedLow;
  // Serial.write(txdata, 3);
  // Serial.println("SPEED LOW");
  newCmd = "SPEED LOW";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}
static esp_err_t speedhigh_handler(httpd_req_t *req) {
  txdata[1] = SpeedHigh;
  // Serial.write(txdata, 3);
  // Serial.println("SPEED HIGH");
  newCmd = "SPEED HIGH";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

static esp_err_t center_handler(httpd_req_t *req) {
  txdata[1] = Center;
  // Serial.write(txdata, 3);
  // Serial.println("CENTER");
  newCmd = "CENTER";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

static esp_err_t rotate_handler(httpd_req_t *req) {
  txdata[1] = RotateCamera;
  // Serial.write(txdata, 31);
  switch (cameraRotationAngle) {
    case 0: cameraRotationAngle = 90; break;
    case 90: cameraRotationAngle = 180; break;
    case 180: cameraRotationAngle = 270; break;
    case 270: cameraRotationAngle = 0; break;
  }
  Serial.println("ROTATE CAMERA: " + String(cameraRotationAngle));

  // newCmd = "ROTATE CAMERA";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

static esp_err_t trotstep_handler(httpd_req_t *req) {
  txdata[1] = TrotStep;
  // Serial.println("TROT STEP");
  newCmd = "TROT STEP";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

static esp_err_t resetimu_handler(httpd_req_t *req) {
  txdata[1] = ResetIMU;
  // Serial.println("RESET IMU");
  newCmd = "RESET IMU";
  httpd_resp_set_type(req, "text/html");
  return httpd_resp_send(req, "OK", 2);
}

int getXp()
{
  return String(legX).toInt();
}

int getYp()
{
  return String(legY).toInt();
}

int getZp()
{
  return String(legZ).toInt();
}

int getLegId()
{
  return String(legNr).toInt();
}

bool getUseIMUSwitch()
{
  // Serial.println("Returning useIMUSwitch: " + String(useIMUSwitch));
  if (String(useIMUSwitch) == "true")
  {
    return true;
  }
  else
  {
    return false;
  }
}

bool getLegMvSwitch()
{
  // Serial.println("Returning legMvSwitch: " + String(legMvSwitch));
  if (String(legMvSwitch) == "true")
  {
    return true;
  }
  else
  {
    return false;
  }
}

int getGaitMoveSwitch()
{
  // Serial.println("Returning gaitModeSwitch: " + String(gaitModeSwitch));
  return String(gaitModeSwitch).toInt();
}

int getTurnModeSwitch()
{
  Serial.println("Returning turnModeSwitch: " + String(turnModeSwitch));
  return String(turnModeSwitch).toInt();
}

bool getStepLeftSwitch()
{
  // Serial.println("Returning stepLeftSwitch: " + String(stepLeftSwitch));
  if (String(stepLeftSwitch) == "true")
  {
    return true;
  }
  else
  {
    return false;
  }
}

bool getStepRightSwitch()
{
  // Serial.println("Returning stepRightSwitch: " + String(stepRightSwitch));
  if (String(stepRightSwitch) == "true")
  {
    return true;
  }
  else
  {
    return false;
  }
}

int getLegMoveStep()
{
  MOVESTEP = String(legMoveStep).toInt();
  return String(legMoveStep).toInt();//.toFloat();
}

float getLegMvSpd()
{
  MOVE_SPEED = String(legMvSpd).toFloat();
  return String(legMvSpd).toFloat();//toInt();
}


int getTick()
{
  ticksPerStep = String(ticksPerStepStr).toInt();
  return String(ticksPerStepStr).toInt();//.toFloat();
}


String getNewCmd()
{
  return newCmd;
}



void ackCmd()
{
  newCmd = "IDLE";
}

void setHasIMUSensor(bool hasIMU)
{
  hasIMUSensor = hasIMU;
}


void setDistance(int dist)
{
  range = dist;
}

void setLegNr(int leg)
{
  legNr_int = leg;
}

void setLegX(int X)
{
  legX_int = X;
}

void setLegY(int Y)
{
  legY_int = Y;
}

void setLegZ(int Z)
{
  legZ_int = Z;
}


//////////////////////////////new/////////////////////////////////

void startCameraServer(String cameraName) {

  pageTitle = cameraName;
  uint32_t i;
  httpd_config_t config = HTTPD_DEFAULT_CONFIG_demo();

  httpd_uri_t forward_uri = {
    .uri = "/forward",
    .method = HTTP_GET,
    .handler = forward_handler,
    .user_ctx = NULL
  };

  httpd_uri_t start_uri = {
    .uri = "/start",
    .method = HTTP_GET,
    .handler = start_handler,
    .user_ctx = NULL
  };

  httpd_uri_t back_uri = {
    .uri = "/back",
    .method = HTTP_GET,
    .handler = back_handler,
    .user_ctx = NULL
  };

  httpd_uri_t stop_uri = {
    .uri = "/stop",
    .method = HTTP_GET,
    .handler = stop_handler,
    .user_ctx = NULL
  };

  httpd_uri_t left_uri = {
    .uri = "/left",
    .method = HTTP_GET,
    .handler = left_handler,
    .user_ctx = NULL
  };

  httpd_uri_t right_uri = {
    .uri = "/right",
    .method = HTTP_GET,
    .handler = right_handler,
    .user_ctx = NULL
  };

  //////////////////////////////new/////////////////////////////////

  httpd_uri_t sonaron_uri = {
                            .uri = "/sonaron",
                            .method = HTTP_GET,
                            .handler = sonaron_handler,
                            .user_ctx = NULL
  };

  httpd_uri_t sonaroff_uri = {
                            .uri = "/sonaroff",
                            .method = HTTP_GET,
                            .handler = sonaroff_handler,
                            .user_ctx = NULL
  };

  httpd_uri_t stepleft_uri = { 
                             .uri = "/stepleft",
                             .method = HTTP_GET,
                             .handler = stepleft_handler,
                             .user_ctx = NULL
  };

  httpd_uri_t stepright_uri = { 
                             .uri = "/stepright",
                             .method = HTTP_GET,
                             .handler = stepright_handler,
                             .user_ctx = NULL
  };

  httpd_uri_t crouch_uri = {
                             .uri = "/crouch",
                             .method = HTTP_GET,
                             .handler = crouch_handler,
                             .user_ctx = NULL
  };


  httpd_uri_t stand_uri = {
                             .uri = "/stand",
                             .method = HTTP_GET,
                             .handler = stand_handler,
                             .user_ctx = NULL
  };

  //////////////////////////////new/////////////////////////////////

  httpd_uri_t ledon_uri = {
    .uri = "/ledon",
    .method = HTTP_GET,
    .handler = ledon_handler,
    .user_ctx = NULL
  };

  httpd_uri_t ledoff_uri = {
    .uri = "/ledoff",
    .method = HTTP_GET,
    .handler = ledoff_handler,
    .user_ctx = NULL
  };

  httpd_uri_t index_uri = {
    .uri = "/",
    .method = HTTP_GET,
    .handler = index_handler,
    .user_ctx = NULL
  };

  httpd_uri_t status_uri = {
    .uri = "/status",
    .method = HTTP_GET,
    .handler = status_handler,
    .user_ctx = NULL
  };

  httpd_uri_t cmd_uri = {
    .uri = "/control",
    .method = HTTP_GET,
    .handler = cmd_handler,
    .user_ctx = NULL
  };

  httpd_uri_t ml_uri = {
    .uri = "/ml",
    .method = HTTP_GET,
    .handler = ml_handler,
    .user_ctx = NULL
  };

  httpd_uri_t capture_uri = {
    .uri = "/capture",
    .method = HTTP_GET,
    .handler = capture_handler,
    .user_ctx = NULL
  };

  httpd_uri_t stream_uri = {
    .uri = "/stream",
    .method = HTTP_GET,
    .handler = stream_handler,
    .user_ctx = NULL
  };

  httpd_uri_t speedlow_uri = {
                               .uri = "/speedlow",
                               .method = HTTP_GET,
                               .handler = speedlow_handler,
                               .user_ctx = NULL
  };

  httpd_uri_t speedhigh_uri = {
                                .uri = "/speedhigh",
                                .method = HTTP_GET,
                                .handler = speedhigh_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t ping_uri = {
                                .uri = "/ping",
                                .method = HTTP_GET,
                                .handler = ping_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t legpos_uri = {
                                .uri = "/legpos",
                                .method = HTTP_GET,
                                .handler = legpos_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t center_uri = {
                                .uri = "/center",
                                .method = HTTP_GET,
                                .handler = center_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t rollleft_uri = {
                                .uri = "/rollleft",
                                .method = HTTP_GET,
                                .handler = rollleft_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t rollright_uri = {
                                .uri = "/rollright",
                                .method = HTTP_GET,
                                .handler = rollright_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t lookleft_uri = {
                                .uri = "/lookleft",
                                .method = HTTP_GET,
                                .handler = lookleft_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t lookright_uri = {
                                .uri = "/lookright",
                                .method = HTTP_GET,
                                .handler = lookright_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t lookup_uri = {
                                .uri = "/lookup",
                                .method = HTTP_GET,
                                .handler = lookup_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t lookdown_uri = {
                                .uri = "/lookdown",
                                .method = HTTP_GET,
                                .handler = lookdown_handler,
                                .user_ctx = NULL
  };


  httpd_uri_t shiftleft_uri = {
                                .uri = "/shiftleft",
                                .method = HTTP_GET,
                                .handler = shiftleft_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t shiftright_uri = {
                                .uri = "/shiftright",
                                .method = HTTP_GET,
                                .handler = shiftright_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t shiftup_uri = {
                                .uri = "/shiftup",
                                .method = HTTP_GET,
                                .handler = shiftup_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t shiftdown_uri = {
                                .uri = "/shiftdown",
                                .method = HTTP_GET,
                                .handler = shiftdown_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t shiftfwd_uri = {
                                .uri = "/shiftfwd",
                                .method = HTTP_GET,
                                .handler = shiftfwd_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t shiftback_uri = {
                                .uri = "/shiftback",
                                .method = HTTP_GET,
                                .handler = shiftback_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t calibrate_uri = {
                                .uri = "/calibrate",
                                .method = HTTP_GET,
                                .handler = calibrate_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t sit_uri = {
                                .uri = "/sit",
                                .method = HTTP_GET,
                                .handler = sit_handler,
                                .user_ctx = NULL
  };


  httpd_uri_t rotate_uri = {
                                .uri = "/rotate",
                                .method = HTTP_GET,
                                .handler = rotate_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t trotstep_uri = {
                                .uri = "/trotstep",
                                .method = HTTP_GET,
                                .handler = trotstep_handler,
                                .user_ctx = NULL
  };

  httpd_uri_t resetimu_uri = {
                                .uri = "/rstimu",
                                .method = HTTP_GET,
                                .handler = resetimu_handler,
                                .user_ctx = NULL
  };

  ra_filter_init(&ra_filter, 21);
  Serial.printf("Starting web server on port: '%d'", config.server_port);


  if (httpd_start(&camera_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(camera_httpd, &index_uri);
    httpd_register_uri_handler(camera_httpd, &forward_uri);
    httpd_register_uri_handler(camera_httpd, &start_uri);
    httpd_register_uri_handler(camera_httpd, &back_uri);
    httpd_register_uri_handler(camera_httpd, &stop_uri);
    httpd_register_uri_handler(camera_httpd, &left_uri);
    httpd_register_uri_handler(camera_httpd, &right_uri);
    httpd_register_uri_handler(camera_httpd, &ledon_uri);
    httpd_register_uri_handler(camera_httpd, &ledoff_uri);
    //////////////////////////////new/////////////////////////////////
    httpd_register_uri_handler(camera_httpd, &sonaron_uri);
    httpd_register_uri_handler(camera_httpd, &sonaroff_uri);
    httpd_register_uri_handler(camera_httpd, &stepleft_uri);
    httpd_register_uri_handler(camera_httpd, &stepright_uri);
    httpd_register_uri_handler(camera_httpd, &stand_uri);
    httpd_register_uri_handler(camera_httpd, &crouch_uri);
    httpd_register_uri_handler(camera_httpd, &speedlow_uri);
    httpd_register_uri_handler(camera_httpd, &speedhigh_uri);
    httpd_register_uri_handler(camera_httpd, &ping_uri);
    httpd_register_uri_handler(camera_httpd, &center_uri);
    httpd_register_uri_handler(camera_httpd, &ml_uri);
    httpd_register_uri_handler(camera_httpd, &capture_uri);
    httpd_register_uri_handler(camera_httpd, &legpos_uri);    

    httpd_register_uri_handler(camera_httpd, &lookup_uri);    
    httpd_register_uri_handler(camera_httpd, &lookleft_uri);    
    httpd_register_uri_handler(camera_httpd, &lookright_uri);    
    httpd_register_uri_handler(camera_httpd, &lookdown_uri);    
    httpd_register_uri_handler(camera_httpd, &rollleft_uri);    
    httpd_register_uri_handler(camera_httpd, &rollright_uri);    

    httpd_register_uri_handler(camera_httpd, &shiftup_uri);    
    httpd_register_uri_handler(camera_httpd, &shiftleft_uri);    
    httpd_register_uri_handler(camera_httpd, &shiftright_uri);    
    httpd_register_uri_handler(camera_httpd, &shiftdown_uri);    
    httpd_register_uri_handler(camera_httpd, &shiftfwd_uri);    
    httpd_register_uri_handler(camera_httpd, &shiftback_uri);    

    httpd_register_uri_handler(camera_httpd, &calibrate_uri);    
    httpd_register_uri_handler(camera_httpd, &sit_uri);    
    httpd_register_uri_handler(camera_httpd, &rotate_uri);    
    httpd_register_uri_handler(camera_httpd, &trotstep_uri);    
    httpd_register_uri_handler(camera_httpd, &resetimu_uri);    
    
    //////////////////////////////new/////////////////////////////////
  }

  
  config.server_port += 1;
  config.ctrl_port += 1;
  Serial.printf("Starting stream server on port: '%d'", config.server_port);
  if (httpd_start(&stream_httpd, &config) == ESP_OK) {
    httpd_register_uri_handler(stream_httpd, &stream_uri);
  }
  
}


